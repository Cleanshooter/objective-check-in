angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('myGeoEventsCtrl', function($scope) {

})
   
.controller('availableGeoEventsCtrl', function($scope) {

})
      
.controller('geoEventDetailsCtrl', function($scope) {

})
 